package com.fdmgroup.Spring_core_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
